package com.example.volumerecorder;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView statusText;
    private static final String ACCESSIBILITY_SERVICE = "com.example.volumerecorder/.VolumeAccessibilityService";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        
        if (!isAccessibilityServiceEnabled()) {
            statusText.setText("접근성 권한이 필요합니다.\n설정에서 켜주세요.");
            openAccessibilitySettings();
        } else {
            statusText.setText("준비 완료!\n볼륨 아래키를 1초 안에\n2번 누르면 녹음 시작\n다시 2번 누르면 중지");
        }
        
        startService(new Intent(this, RecordingService.class));
    }

    private boolean isAccessibilityServiceEnabled() {
        ComponentName expectedComponentName = new ComponentName(this, VolumeAccessibilityService.class);
        String enabledServicesSetting = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        
        if (enabledServicesSetting == null) return false;
        
        return enabledServicesSetting.contains(expectedComponentName.flattenToString());
    }

    private void openAccessibilitySettings() {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(intent);
    }
}
