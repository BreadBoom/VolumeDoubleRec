package com.example.volumerecorder;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class VolumeAccessibilityService extends AccessibilityService {
    private long lastVolumeDownTime = 0;
    private int volumeDownCount = 0;
    private static final long DOUBLE_TAP_TIMEOUT = 1000;
    private SharedPreferences prefs;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences("recorder_prefs", MODE_PRIVATE);
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                handleVolumeDownPress();
            }
            return true;
        }
        return false;
    }

    private void handleVolumeDownPress() {
        long currentTime = System.currentTimeMillis();
        
        if (currentTime - lastVolumeDownTime > DOUBLE_TAP_TIMEOUT) {
            volumeDownCount = 1;
        } else {
            volumeDownCount++;
        }
        
        lastVolumeDownTime = currentTime;
        
        if (volumeDownCount == 2) {
            boolean isRecording = prefs.getBoolean("is_recording", false);
            if (isRecording) {
                stopRecording();
            } else {
                startRecording();
            }
            volumeDownCount = 0;
        }
    }

    private void startRecording() {
        Intent intent = new Intent(this, RecordingService.class);
        intent.setAction("START_RECORDING");
        startService(intent);
        
        prefs.edit().putBoolean("is_recording", true).apply();
    }

    private void stopRecording() {
        Intent intent = new Intent(this, RecordingService.class);
        intent.setAction("STOP_RECORDING");
        startService(intent);
        
        prefs.edit().putBoolean("is_recording", false).apply();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }
}
