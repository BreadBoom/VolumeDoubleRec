package com.example.volumedoublerec;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class VolumeAccessibilityService extends AccessibilityService {
    private static final long DOUBLE_PRESS_MS = 1000L;
    private long lastDownPress = 0L;

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event.getKeyCode() != KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        if (event.getAction() != KeyEvent.ACTION_DOWN || event.getRepeatCount() != 0) return true;

        long now = SystemClock.elapsedRealtime();
        if (lastDownPress > 0 && now - lastDownPress <= DOUBLE_PRESS_MS) {
            lastDownPress = 0L;
            Intent intent = new Intent(this, RecordingService.class);
            intent.setAction(RecordingService.ACTION_TOGGLE);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        } else {
            lastDownPress = now;
        }

        // 볼륨 아래 키를 이 앱의 전용 녹음 키처럼 사용하기 위해 소비합니다.
        // 볼륨 조절은 볼륨 위 키 또는 화면 슬라이더를 사용하세요.
        return true;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }
}
