package com.example.volumedoublerec;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;

import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecordingService extends Service {
    public static final String ACTION_ARM = "com.example.volumedoublerec.ARM";
    public static final String ACTION_TOGGLE = "com.example.volumedoublerec.TOGGLE";
    public static final String ACTION_STOP_SERVICE = "com.example.volumedoublerec.STOP_SERVICE";

    private static final String CHANNEL_ID = "vol_rec_service";
    private static final int NOTIFICATION_ID = 2207;

    private MediaRecorder recorder;
    private ParcelFileDescriptor outputPfd;
    private Uri outputUri;
    private PowerManager.WakeLock wakeLock;
    private boolean recording = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        recording = getSharedPreferences("state", MODE_PRIVATE).getBoolean("recording", false);
        // 프로세스가 새로 뜬 경우 실제 recorder 객체는 없으므로 상태를 정리합니다.
        if (recording) {
            recording = false;
            saveState(true, false);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        startAsForeground();
        saveState(true, recording);

        if (ACTION_TOGGLE.equals(action)) {
            if (recording) stopRecording(); else startRecording();
        } else if (ACTION_STOP_SERVICE.equals(action)) {
            if (recording) stopRecording();
            saveState(false, false);
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        Notification notification = buildNotification(recording);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification(boolean isRecording) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = isRecording ? "녹음 중" : "볼륨 더블 녹음 대기 중";
        String text = isRecording ? "볼륨 아래 버튼을 1초 안에 두 번 누르면 저장 후 중지됩니다." : "볼륨 아래 버튼을 1초 안에 두 번 누르면 녹음이 시작됩니다.";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(pi)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "볼륨 더블 녹음", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("화면이 꺼져 있을 때도 녹음 제어를 유지하기 위한 서비스");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void startRecording() {
        if (recording) return;
        ContentResolver resolver = getContentResolver();
        String name = "REC_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date()) + ".m4a";

        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            if (Build.VERSION.SDK_INT >= 29) {
                String base = Build.VERSION.SDK_INT >= 31 ? Environment.DIRECTORY_RECORDINGS : Environment.DIRECTORY_MUSIC;
                values.put(MediaStore.Audio.Media.RELATIVE_PATH, base + "/rec");
                values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            }

            outputUri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (outputUri == null) throw new IllegalStateException("저장 파일을 만들 수 없습니다.");
            outputPfd = resolver.openFileDescriptor(outputUri, "w");
            if (outputPfd == null) throw new IllegalStateException("저장 파일을 열 수 없습니다.");
            FileDescriptor fd = outputPfd.getFileDescriptor();

            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(fd);
            recorder.prepare();
            recorder.start();

            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VolumeDoubleRec:Recording");
            wakeLock.acquire();

            recording = true;
            saveState(true, true);
            notifyChanged();
            vibrate(70);
        } catch (Exception e) {
            cleanupFailedRecording();
        }
    }

    private void stopRecording() {
        if (!recording) return;
        boolean good = true;
        try {
            recorder.stop();
        } catch (Exception e) {
            good = false;
        }
        try { recorder.reset(); } catch (Exception ignored) { }
        try { recorder.release(); } catch (Exception ignored) { }
        recorder = null;

        try { if (outputPfd != null) outputPfd.close(); } catch (Exception ignored) { }
        outputPfd = null;

        if (outputUri != null) {
            if (good && Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Audio.Media.IS_PENDING, 0);
                getContentResolver().update(outputUri, done, null, null);
            } else if (!good) {
                getContentResolver().delete(outputUri, null, null);
            }
        }
        outputUri = null;
        releaseWakeLock();
        recording = false;
        saveState(true, false);
        notifyChanged();
        vibratePattern();
    }

    private void cleanupFailedRecording() {
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        try { if (outputPfd != null) outputPfd.close(); } catch (Exception ignored) { }
        outputPfd = null;
        if (outputUri != null) {
            try { getContentResolver().delete(outputUri, null, null); } catch (Exception ignored) { }
        }
        outputUri = null;
        releaseWakeLock();
        recording = false;
        saveState(true, false);
        notifyChanged();
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }

    private void notifyChanged() {
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, buildNotification(recording));
    }

    private void saveState(boolean armed, boolean isRecording) {
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("armed", armed).putBoolean("recording", isRecording).apply();
    }

    private void vibrate(long millis) {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null) return;
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE));
        else v.vibrate(millis);
    }

    private void vibratePattern() {
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v == null) return;
        long[] p = new long[]{0, 60, 80, 60};
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(p, -1));
        else v.vibrate(p, -1);
    }

    @Override
    public void onDestroy() {
        if (recording) stopRecording();
        saveState(false, false);
        releaseWakeLock();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
