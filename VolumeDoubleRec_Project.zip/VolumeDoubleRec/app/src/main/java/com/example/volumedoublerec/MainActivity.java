package com.example.volumedoublerec;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PERMISSIONS = 100;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button permissionButton = findViewById(R.id.permissionButton);
        Button accessibilityButton = findViewById(R.id.accessibilityButton);
        Button startListenerButton = findViewById(R.id.startListenerButton);
        Button batteryButton = findViewById(R.id.batteryButton);

        permissionButton.setOnClickListener(v -> requestNeededPermissions());
        accessibilityButton.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "설치된 앱 → 볼륨 더블 녹음 서비스를 켜세요.", Toast.LENGTH_LONG).show();
        });
        startListenerButton.setOnClickListener(v -> startBackgroundListener());
        batteryButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                Toast.makeText(this, "배터리 → 제한 없음으로 설정하세요.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void requestNeededPermissions() {
        List<String> permissions = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (permissions.isEmpty()) {
            Toast.makeText(this, "필요한 권한이 이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show();
        } else {
            requestPermissions(permissions.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    private void startBackgroundListener() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "먼저 마이크 권한을 허용하세요.", Toast.LENGTH_LONG).show();
            requestNeededPermissions();
            return;
        }
        Intent service = new Intent(this, RecordingService.class);
        service.setAction(RecordingService.ACTION_ARM);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        Toast.makeText(this, "백그라운드 대기를 시작했습니다.", Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void updateStatus() {
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean acc = isAccessibilityServiceEnabled(this, VolumeAccessibilityService.class);
        boolean armed = getSharedPreferences("state", MODE_PRIVATE).getBoolean("armed", false);
        boolean recording = getSharedPreferences("state", MODE_PRIVATE).getBoolean("recording", false);

        String text = "마이크 권한: " + (mic ? "허용됨" : "필요") +
                "\n접근성 서비스: " + (acc ? "켜짐" : "꺼짐") +
                "\n백그라운드 대기: " + (armed ? "실행 중" : "정지") +
                "\n녹음: " + (recording ? "녹음 중" : "대기 중");
        statusText.setText(text);
    }

    private static boolean isAccessibilityServiceEnabled(Context context, Class<?> serviceClass) {
        String expected = new ComponentName(context, serviceClass).flattenToString();
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        for (String component : TextUtils.split(enabled, ":")) {
            if (expected.equalsIgnoreCase(component)) return true;
        }
        return false;
    }
}
