# No shrinking rules needed.
